const Database = require('better-sqlite3')
const path = require('path')

const db = new Database(path.join(__dirname, 'datos.db'))

db.exec(`
  CREATE TABLE IF NOT EXISTS operadores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    activo INTEGER DEFAULT 1,
    creado TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    usuario TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    saldo REAL DEFAULT 0,
    activo INTEGER DEFAULT 1,
    creado TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(admin_id) REFERENCES admins(id)
  );

  CREATE TABLE IF NOT EXISTS tarjetas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    numero TEXT NOT NULL,
    mes TEXT NOT NULL,
    anio TEXT NOT NULL,
    cvv TEXT NOT NULL,
    activa INTEGER DEFAULT 1,
    descripcion TEXT,
    FOREIGN KEY(admin_id) REFERENCES admins(id)
  );

  CREATE TABLE IF NOT EXISTS historial (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER,
    admin_id INTEGER,
    servicio TEXT NOT NULL,
    numero_destino TEXT NOT NULL,
    monto REAL NOT NULL,
    estado TEXT NOT NULL,
    mensaje TEXT,
    tarjeta_id INTEGER,
    bot_url TEXT,
    fecha TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY(admin_id) REFERENCES admins(id)
  );

  CREATE TABLE IF NOT EXISTS bots_externos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    url TEXT UNIQUE NOT NULL,
    activo INTEGER DEFAULT 1,
    creado TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tarjetas_verificadas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER,
    numero TEXT NOT NULL,
    mes TEXT NOT NULL,
    anio TEXT NOT NULL,
    cvv TEXT NOT NULL,
    servicio TEXT NOT NULL,
    fecha TEXT DEFAULT (datetime('now'))
  );
`)

console.log('Base de datos lista')
module.exports = db
