const express = require('express')

const app = express()
const PORT = process.env.PORT || 4000
const API_KEY = process.env.API_KEY || 'clave_secreta_bot'

app.use(express.json())

// Verificacion simple por API key
function auth(req, res, next) {
  const key = req.headers['x-api-key']
  if (key !== API_KEY) return res.status(401).json({ error: 'No autorizado' })
  next()
}

app.post('/recargar', auth, async (req, res) => {
  const { servicio, numero, monto, tarjetas } = req.body
  if (!servicio || !numero || !monto || !tarjetas?.length) {
    return res.status(400).json({ error: 'Faltan datos' })
  }

  try {
    const bot = require('./bots/' + servicio)
    const resultado = await bot.recargar(numero, String(monto), tarjetas)
    res.json(resultado)
  } catch(e) {
    res.status(500).json({ ok: false, mensaje: 'Bot no disponible: ' + e.message })
  }
})

app.get('/ping', (req, res) => {
  res.json({ ok: true, servicios: ['movistar', 'personal'] })
})

app.listen(PORT, () => console.log('Bot server en puerto ' + PORT))
