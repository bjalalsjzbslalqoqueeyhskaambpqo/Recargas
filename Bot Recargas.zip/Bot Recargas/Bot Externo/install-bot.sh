#!/bin/bash

# Instalar Node.js 20
apt update && apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Dependencias de Chromium
apt install -y libgbm1 libasound2 libatk1.0-0 libc6 libcairo2 libcups2 \
  libdbus-1-3 libexpat1 libfontconfig1 libgdk-pixbuf2.0-0 libglib2.0-0 \
  libgtk-3-0 libnspr4 libpango-1.0-0 libpangocairo-1.0-0 libstdc++6 \
  libx11-6 libx11-xcb1 libxcb1 libxcomposite1 libxcursor1 libxdamage1 \
  libxext6 libxfixes3 libxi6 libxrandr2 libxrender1 libxss1 libxtst6 \
  ca-certificates fonts-liberation libnss3 lsb-release xdg-utils wget

npm install -g pm2

timedatectl set-timezone America/Argentina/Buenos_Aires

# Crear estructura
mkdir -p ~/bot/bots

cd ~/bot
npm init -y
npm install express playwright-extra puppeteer-extra-plugin-stealth playwright
npx playwright install chromium

# Iniciar con PM2
# Recordar setear variables de entorno:
# PORT=4000
# API_KEY=clave_secreta_bot
pm2 start bot-server.js --name bot \
  --env PORT=4000 \
  --env API_KEY=clave_secreta_bot
pm2 save
pm2 startup

# Abrir puerto
ufw allow 4000
