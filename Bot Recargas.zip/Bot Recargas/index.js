const express = require('express')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const rateLimit = require('express-rate-limit')
const db = require('./db')
const path = require('path')

const app = express()
const SECRET = process.env.SECRET || 'cambiar_en_produccion'
const PORT = process.env.PORT || 3000

app.use(express.json())
app.use(express.static(path.join(__dirname, '../public')))

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, message: { error: 'Demasiados intentos' } })
const recargarLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 30, message: { error: 'Limite alcanzado' } })

function authOperador(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Sin token' })
  try {
    const data = jwt.verify(token, SECRET)
    if (data.rol !== 'operador') return res.status(403).json({ error: 'No autorizado' })
    req.operador = data
    next()
  } catch { res.status(401).json({ error: 'Token invalido' }) }
}

function authAdmin(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Sin token' })
  try {
    const data = jwt.verify(token, SECRET)
    if (data.rol !== 'admin') return res.status(403).json({ error: 'No autorizado' })
    req.admin = data
    next()
  } catch { res.status(401).json({ error: 'Token invalido' }) }
}

function authUsuario(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Sin token' })
  try {
    const data = jwt.verify(token, SECRET)
    if (data.rol !== 'usuario') return res.status(403).json({ error: 'No autorizado' })
    req.usuario = data
    next()
  } catch { res.status(401).json({ error: 'Token invalido' }) }
}

// ── LOGIN ─────────────────────────────────────────────────────────────────────

app.post('/api/operador/login', loginLimiter, async (req, res) => {
  const { usuario, password } = req.body
  const row = db.prepare('SELECT * FROM operadores WHERE usuario = ?').get(usuario)
  if (!row) return res.status(401).json({ error: 'Credenciales invalidas' })
  const ok = await bcrypt.compare(password, row.password)
  if (!ok) return res.status(401).json({ error: 'Credenciales invalidas' })
  const token = jwt.sign({ id: row.id, usuario: row.usuario, rol: 'operador' }, SECRET, { expiresIn: '12h' })
  res.json({ token })
})

app.post('/api/admin/login', loginLimiter, async (req, res) => {
  const { usuario, password } = req.body
  const row = db.prepare('SELECT * FROM admins WHERE usuario = ? AND activo = 1').get(usuario)
  if (!row) return res.status(401).json({ error: 'Credenciales invalidas' })
  const ok = await bcrypt.compare(password, row.password)
  if (!ok) return res.status(401).json({ error: 'Credenciales invalidas' })
  const token = jwt.sign({ id: row.id, usuario: row.usuario, rol: 'admin' }, SECRET, { expiresIn: '12h' })
  res.json({ token })
})

app.post('/api/login', loginLimiter, async (req, res) => {
  const { usuario, password } = req.body
  const row = db.prepare('SELECT * FROM usuarios WHERE usuario = ? AND activo = 1').get(usuario)
  if (!row) return res.status(401).json({ error: 'Credenciales invalidas' })
  const ok = await bcrypt.compare(password, row.password)
  if (!ok) return res.status(401).json({ error: 'Credenciales invalidas' })
  const token = jwt.sign({ id: row.id, usuario: row.usuario, admin_id: row.admin_id, rol: 'usuario' }, SECRET, { expiresIn: '12h' })
  res.json({ token, saldo: row.saldo })
})

// ── OPERADOR: ADMINS ──────────────────────────────────────────────────────────

app.get('/api/operador/admins', authOperador, (req, res) => {
  res.json(db.prepare('SELECT id, usuario, activo, creado FROM admins').all())
})

app.post('/api/operador/admins', authOperador, async (req, res) => {
  const { usuario, password } = req.body
  if (!usuario || !password) return res.status(400).json({ error: 'Faltan datos' })
  try {
    const hash = await bcrypt.hash(password, 10)
    const r = db.prepare('INSERT INTO admins (usuario, password) VALUES (?, ?)').run(usuario, hash)
    res.json({ id: r.lastInsertRowid, usuario })
  } catch { res.status(400).json({ error: 'Admin ya existe' }) }
})

app.put('/api/operador/admins/:id/activo', authOperador, (req, res) => {
  db.prepare('UPDATE admins SET activo = ? WHERE id = ?').run(req.body.activo, req.params.id)
  res.json({ ok: true })
})

app.delete('/api/operador/admins/:id', authOperador, (req, res) => {
  db.prepare('DELETE FROM admins WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

app.get('/api/operador/historial', authOperador, (req, res) => {
  res.json(db.prepare(`
    SELECT h.*, u.usuario as kiosquero, a.usuario as admin
    FROM historial h
    LEFT JOIN usuarios u ON h.usuario_id = u.id
    LEFT JOIN admins a ON h.admin_id = a.id
    ORDER BY h.fecha DESC LIMIT 200
  `).all())
})

// ── OPERADOR: BOTS EXTERNOS ───────────────────────────────────────────────────

app.get('/api/operador/bots', authOperador, (req, res) => {
  res.json(db.prepare('SELECT * FROM bots_externos').all())
})

app.post('/api/operador/bots', authOperador, (req, res) => {
  const { nombre, url } = req.body
  if (!nombre || !url) return res.status(400).json({ error: 'Faltan datos' })
  try {
    const r = db.prepare('INSERT INTO bots_externos (nombre, url) VALUES (?, ?)').run(nombre, url)
    res.json({ id: r.lastInsertRowid })
  } catch { res.status(400).json({ error: 'URL ya existe' }) }
})

app.put('/api/operador/bots/:id/activo', authOperador, (req, res) => {
  db.prepare('UPDATE bots_externos SET activo = ? WHERE id = ?').run(req.body.activo, req.params.id)
  res.json({ ok: true })
})

app.delete('/api/operador/bots/:id', authOperador, (req, res) => {
  db.prepare('DELETE FROM bots_externos WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// ── ADMIN: USUARIOS ───────────────────────────────────────────────────────────

app.get('/api/admin/usuarios', authAdmin, (req, res) => {
  res.json(db.prepare('SELECT id, usuario, saldo, activo, creado FROM usuarios WHERE admin_id = ?').all(req.admin.id))
})

app.post('/api/admin/usuarios', authAdmin, async (req, res) => {
  const { usuario, password, saldo } = req.body
  if (!usuario || !password) return res.status(400).json({ error: 'Faltan datos' })
  try {
    const hash = await bcrypt.hash(password, 10)
    const r = db.prepare('INSERT INTO usuarios (admin_id, usuario, password, saldo) VALUES (?, ?, ?, ?)').run(req.admin.id, usuario, hash, saldo || 0)
    res.json({ id: r.lastInsertRowid, usuario, saldo: saldo || 0 })
  } catch { res.status(400).json({ error: 'Usuario ya existe' }) }
})

app.put('/api/admin/usuarios/:id/saldo', authAdmin, (req, res) => {
  const { saldo } = req.body
  if (saldo === undefined) return res.status(400).json({ error: 'Falta saldo' })
  const u = db.prepare('SELECT id FROM usuarios WHERE id = ? AND admin_id = ?').get(req.params.id, req.admin.id)
  if (!u) return res.status(403).json({ error: 'No autorizado' })
  db.prepare('UPDATE usuarios SET saldo = ? WHERE id = ?').run(saldo, req.params.id)
  res.json({ ok: true })
})

app.put('/api/admin/usuarios/:id/activo', authAdmin, (req, res) => {
  const u = db.prepare('SELECT id FROM usuarios WHERE id = ? AND admin_id = ?').get(req.params.id, req.admin.id)
  if (!u) return res.status(403).json({ error: 'No autorizado' })
  db.prepare('UPDATE usuarios SET activo = ? WHERE id = ?').run(req.body.activo, req.params.id)
  res.json({ ok: true })
})

app.delete('/api/admin/usuarios/:id', authAdmin, (req, res) => {
  const u = db.prepare('SELECT id FROM usuarios WHERE id = ? AND admin_id = ?').get(req.params.id, req.admin.id)
  if (!u) return res.status(403).json({ error: 'No autorizado' })
  db.prepare('DELETE FROM usuarios WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// ── ADMIN: TARJETAS ───────────────────────────────────────────────────────────

app.get('/api/admin/tarjetas', authAdmin, (req, res) => {
  res.json(db.prepare('SELECT * FROM tarjetas WHERE admin_id = ?').all(req.admin.id))
})

app.post('/api/admin/tarjetas', authAdmin, (req, res) => {
  const { numero, mes, anio, cvv, descripcion } = req.body
  if (!numero || !mes || !anio || !cvv) return res.status(400).json({ error: 'Faltan datos' })
  const r = db.prepare('INSERT INTO tarjetas (admin_id, numero, mes, anio, cvv, descripcion) VALUES (?, ?, ?, ?, ?, ?)').run(req.admin.id, numero, mes, anio, cvv, descripcion || '')
  res.json({ id: r.lastInsertRowid })
})

app.put('/api/admin/tarjetas/:id/activa', authAdmin, (req, res) => {
  const t = db.prepare('SELECT id FROM tarjetas WHERE id = ? AND admin_id = ?').get(req.params.id, req.admin.id)
  if (!t) return res.status(403).json({ error: 'No autorizado' })
  db.prepare('UPDATE tarjetas SET activa = ? WHERE id = ?').run(req.body.activa, req.params.id)
  res.json({ ok: true })
})

app.delete('/api/admin/tarjetas/:id', authAdmin, (req, res) => {
  const t = db.prepare('SELECT id FROM tarjetas WHERE id = ? AND admin_id = ?').get(req.params.id, req.admin.id)
  if (!t) return res.status(403).json({ error: 'No autorizado' })
  db.prepare('DELETE FROM tarjetas WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

app.get('/api/admin/historial', authAdmin, (req, res) => {
  res.json(db.prepare(`
    SELECT h.*, u.usuario FROM historial h
    LEFT JOIN usuarios u ON h.usuario_id = u.id
    WHERE h.admin_id = ?
    ORDER BY h.fecha DESC LIMIT 100
  `).all(req.admin.id))
})

// ── USUARIO: SALDO E HISTORIAL ────────────────────────────────────────────────

app.get('/api/servicios', (req, res) => {
  res.json(require('./servicios'))
})

app.get('/api/saldo', authUsuario, (req, res) => {
  const row = db.prepare('SELECT saldo FROM usuarios WHERE id = ?').get(req.usuario.id)
  res.json({ saldo: row?.saldo || 0 })
})

app.get('/api/historial', authUsuario, (req, res) => {
  res.json(db.prepare('SELECT * FROM historial WHERE usuario_id = ? ORDER BY fecha DESC LIMIT 50').all(req.usuario.id))
})

// ── USUARIO: RECARGAR ─────────────────────────────────────────────────────────

app.post('/api/recargar', authUsuario, recargarLimiter, async (req, res) => {
  const { servicio, numero, monto } = req.body
  if (!servicio || !numero || !monto) return res.status(400).json({ error: 'Faltan datos' })

  const montoNum = parseFloat(monto)
  if (isNaN(montoNum) || montoNum <= 0) return res.status(400).json({ error: 'Monto invalido' })

  let usuario
  try {
    const descontar = db.transaction(() => {
      const u = db.prepare('SELECT * FROM usuarios WHERE id = ? AND activo = 1').get(req.usuario.id)
      if (!u) throw new Error('Usuario inactivo')
      if (u.saldo < montoNum) throw new Error('Saldo insuficiente')
      db.prepare('UPDATE usuarios SET saldo = saldo - ? WHERE id = ?').run(montoNum, req.usuario.id)
      return u
    })
    usuario = descontar()
  } catch(e) {
    return res.status(400).json({ error: e.message })
  }

  const tarjetas = db.prepare('SELECT * FROM tarjetas WHERE admin_id = ? AND activa = 1').all(usuario.admin_id)
  if (!tarjetas.length) {
    db.prepare('UPDATE usuarios SET saldo = saldo + ? WHERE id = ?').run(montoNum, req.usuario.id)
    return res.status(500).json({ error: 'Servicio no disponible. Contacta al administrador.' })
  }

  const bots = db.prepare('SELECT * FROM bots_externos WHERE activo = 1').all()

  let resultado
  if (bots.length) {
    const bot = bots[Math.floor(Math.random() * bots.length)]
    try {
      const r = await fetch(bot.url + '/recargar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.BOT_API_KEY || 'clave_secreta_bot' },
        body: JSON.stringify({ servicio, numero, monto: String(montoNum), tarjetas })
      })
      resultado = await r.json()
      resultado.bot_url = bot.url
    } catch(e) {
      db.prepare('UPDATE usuarios SET saldo = saldo + ? WHERE id = ?').run(montoNum, req.usuario.id)
      return res.status(500).json({ error: 'Bot no disponible' })
    }
  } else {
    try {
      const botLocal = require('./bots/' + servicio)
      resultado = await botLocal.recargar(numero, String(montoNum), tarjetas)
    } catch(e) {
      db.prepare('UPDATE usuarios SET saldo = saldo + ? WHERE id = ?').run(montoNum, req.usuario.id)
      return res.status(500).json({ error: 'Error interno' })
    }
  }

  if (!resultado.ok) {
    db.prepare('UPDATE usuarios SET saldo = saldo + ? WHERE id = ?').run(montoNum, req.usuario.id)
  }

  const tarjeta_id = resultado.tarjeta_idx !== undefined ? tarjetas[resultado.tarjeta_idx].id : null
  db.prepare('INSERT INTO historial (usuario_id, admin_id, servicio, numero_destino, monto, estado, mensaje, tarjeta_id, bot_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').run(
    req.usuario.id, usuario.admin_id, servicio, numero, montoNum,
    resultado.ok ? 'exitoso' : 'fallido', resultado.mensaje,
    tarjeta_id, resultado.bot_url || null
  )

  res.json(resultado)
})

// ── INIT ──────────────────────────────────────────────────────────────────────

async function init() {
  const op = db.prepare('SELECT * FROM operadores WHERE usuario = ?').get('SheyingAP')
  if (!op) {
    const hash = await bcrypt.hash('SheisAdm2626', 10)
    db.prepare('INSERT INTO operadores (usuario, password) VALUES (?, ?)').run('SheyingAP', hash)
    console.log('Operador creado: SheyingAP')
  }
}

init()
app.listen(PORT, () => console.log('Servidor en puerto ' + PORT))

// Limpieza de historial cada 24 horas — borra registros de mas de 7 dias
function limpiarHistorial() {
  const eliminados = db.prepare("DELETE FROM historial WHERE fecha < datetime('now', '-7 days')").run()
  if (eliminados.changes > 0) console.log('Historial: ' + eliminados.changes + ' registros eliminados')
}

limpiarHistorial()
setInterval(limpiarHistorial, 24 * 60 * 60 * 1000)
