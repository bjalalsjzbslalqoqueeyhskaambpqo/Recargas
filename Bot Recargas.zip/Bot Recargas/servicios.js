const servicios = {
  movistar: {
    nombre: 'Movistar',
    montos: [2000, 4000, 5000, 6000, 7000, 8000, 10000, 15000, 20000]
  },
  personal: {
    nombre: 'Personal',
    montos: [4000, 5000, 6000, 7000, 8000, 9000, 10000, 12000, 15000, 30000]
  }
}

module.exports = servicios
